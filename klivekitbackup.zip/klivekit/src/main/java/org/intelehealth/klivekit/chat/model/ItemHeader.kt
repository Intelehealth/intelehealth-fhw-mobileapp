package org.intelehealth.klivekit.chat.model

/**
 * Created by Vaghela Mithun R. on 03-08-2023 - 19:27.
 * Email : mithun@intelehealth.org
 * Mob   : +919727206702
 **/
interface ItemHeader {
    fun isHeader(): Boolean
    fun createdDate(): String
}